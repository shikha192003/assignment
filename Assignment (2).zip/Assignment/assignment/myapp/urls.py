from django.urls import path
from . views import home,update_configuration,ConfigurationView
urlpatterns = [
    path('',home,name='home'),
    path('update/',update_configuration,name='update_configuration'),
    path('api/configurations/<str:id>/',ConfigurationView.as_view(),name='configuration_view'),
]
