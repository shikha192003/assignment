from django.shortcuts import render
from django.http import JsonResponse
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
import json
from. views import ConfigurationView

# Create your views here.
def home(request):
    return render(request,'home.html')

def update_configuration(request):
    return render(request,'update.html')

class ConfigurationView(View):
    @method_decorator(csrf_exempt)
    def dispatch(self,*args,**kwargs):
        return super().dispatch(*args,**kwargs)
    def get(self,request,*arges,**kwargs):
        configuration_id=kwargs.get('id')
        array_2d=[
            ['sym1','sym2','sym3'],
            ['sym4','sym6','sym8'],
            ['sym5','sym1','sym0']
            ]
        return JsonResponse(array_2d,safe=False)
    def put(self,request,*args,**kwargs):
        configuration_id=kwargs.get('id')
        try:
            data=json.loads(request.body.decode('utf-8'))
            remark=data.get('remark')
            print(f"Updated remark for configuration {configuration_id}:{remark}")
            response_data={'message':'success'}
            return JsonResponse(response_data)
        except json.JSONDecodeError:
            response_data={'error':'Invalid JSON formate in therequest body'}
            return JsonResponse(response_data,status=400)