from django.db import models

# Create your models here.
class Configuration(models.Model):
    configId=models.CharField(max_length=255,unique=True)
    remark=models.TextField()
